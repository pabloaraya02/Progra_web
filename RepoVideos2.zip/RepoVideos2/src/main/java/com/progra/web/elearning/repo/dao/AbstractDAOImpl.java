package com.progra.web.elearning.repo.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;


import java.io.Serializable;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementacion de la clase para ingreso y consulta de 
 * de una base de datos en SQL
 * @author Dario
 * @param <E>
 * @param <I> 
 */
public abstract class AbstractDAOImpl<E, I extends Serializable> implements AbstractDAO<E,I> {

    private Class<E> entityClass;

    protected AbstractDAOImpl(Class<E> entityClass) {
        this.entityClass = entityClass;
    }

    /*Inyeccion de dependencia por atributo para obtener la session del
    archivo application-context.xml*/
    @Autowired
    private SessionFactory sessionFactory;

    public Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    public E findById(I id) {
        return (E) getCurrentSession().get(entityClass, id);
    }

    @Override
    public void saveOrUpdate(E e) {
        getCurrentSession().saveOrUpdate(e);
    }

    @Override
    public boolean delete(E e) {
        if(e!=null){
        getCurrentSession().delete(e);
        return true;
        }
        return false;
    }

    @Override
    public List<E> findByCriteria(Criterion criterion) {
        Criteria criteria = getCurrentSession().createCriteria(entityClass);
        criteria.add(criterion);
        return criteria.list();
    }
    
    @Override
    public List<E> getAll(String query) {
        return sessionFactory.getCurrentSession().createQuery(query).list();
    }
    @Override
    public E findByFilter(List<Criterion> criterion) {
        Criteria criteria = getCurrentSession().createCriteria(entityClass);
        for(int i=0; i<criterion.size(); i++){
            criteria.add(criterion.get(i));
        }
        return (E) criteria.list().get(0);
    }
    @Override
    @Transactional(readOnly = false)
    public E saveOrUpdateWithReturn(E e) {
         getCurrentSession().save(e);
  //      getCurrentSession().saveOrUpdate(e);
        getCurrentSession().flush();
        return e;
    }
    
}
