/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.progra.web.elearning.repo.dao;

import com.progra.web.elearning.repo.model.VideoMDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

/**
 * Clase que se encarga de hacer el mantenimiento de 
 * video en la base de datos de MongoDB
 * @author Dario
 */
@Repository
public class VideoMDBDAO {

    /*Inyeccion de dependencia al archivo application-context.xml*/
    @Autowired
    private MongoTemplate mongoTemplate;

    public MongoTemplate getMongoTemplate() {
        return mongoTemplate;
    }

    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    /**
     * Metodo de consulta de MongoDB
     * @param nombreArchivo
     * @param recurso
     * @return 
     */
    public VideoMDB consultar(String nombreArchivo, int recurso) {
        Query searchArchive = new Query(Criteria.where("nombreArchivo").is(nombreArchivo).and("recurso").is(recurso));
        MongoOperations mongoOperation = (MongoOperations) mongoTemplate;
        VideoMDB video = mongoOperation.findOne(searchArchive, VideoMDB.class);
        return video;

    }

    /**
     * Metodo de insercion a MongoDB
     * @param video 
     */
    public void saveVideo(VideoMDB video) {
        MongoOperations mongoOperation = (MongoOperations) mongoTemplate;
        mongoOperation.save(video);
    }

}
