package com.progra.web.elearning.repo.dao;

import com.progra.web.elearning.repo.model.Video;
import java.util.List;

/**
 * Interface para la clase Especifica de video que 
 * extiende de AbstractDAO
 * @author Dario
 */
public interface VideoDAO extends AbstractDAO<Video, String> {
    void saveVideo(Video video);
    List<Video> findVideos(String curso);
    Video findVideo(String nombreArchivo);
    List<Video> findAllVideos();
    boolean deleteVideo(Video v);
}
