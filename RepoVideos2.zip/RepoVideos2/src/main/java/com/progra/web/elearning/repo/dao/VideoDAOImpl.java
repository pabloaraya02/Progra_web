package com.progra.web.elearning.repo.dao;


import com.progra.web.elearning.repo.model.Video;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementacion para la interface de videoDAO
 * que se encarga del CRUD de Video
 * Por medio de la etiqueta repository,
 * Se almacena en Spring la instancia de esta clase
 * @author Dario
 */
@Repository
public class VideoDAOImpl extends 
        AbstractDAOImpl<Video, String> implements VideoDAO, Serializable {

	 @Autowired
	 private SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		  return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		  this.sessionFactory = sessionFactory;
	}
		 
	
    protected VideoDAOImpl() {
        super(Video.class);
    }

    @Override
    @Transactional
    public void saveVideo(Video video) {
        saveOrUpdate(video);
    }

    @Override
    public List<Video> findVideos(String curso) {
        return findByCriteria(Restrictions.like("curso", curso, MatchMode.START));
    }
    
    @Override
    public List<Video> findAllVideos() {
        return getAll("from Video");
    }
    
    @Override
    public Video findVideo(String nombreArchivo){
        if(findByCriteria(Restrictions.eq("nombreArchivo", Integer.valueOf(nombreArchivo))).isEmpty()){    
            return null;
        }else{
         findByCriteria(Restrictions.eq("nombreArchivo", Integer.valueOf(nombreArchivo))).get(0);   
         return findByCriteria(Restrictions.eq("nombreArchivo", Integer.valueOf(nombreArchivo))).get(0);
        }
    }

    @Override
    public boolean deleteVideo(Video v) {
        return delete(v);
    }
    
}
