/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.progra.web.elearning.repo.service;

import com.progra.web.elearning.repo.dao.VideoMDBDAO;
import com.progra.web.elearning.repo.model.VideoMDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Dario
 */
/**
 * Esta clase se utiliza para hacer la conexion con la base de datos
 * en MongoDB
 * @author Dario
 */
@Service
public class VideoServiceMDB {
    
    /*Hace una inyecccion por dependencia al atributo de la clase 
    videoMDBDAO para poder acceder a los metodos de insercion y actualizacion en 
    la base de datos que esta en No SQL*/
    @Autowired
    private VideoMDBDAO videoMDBDAO;

    public void setVideoMDBDAO(VideoMDBDAO videoMDBDAO) {
		this.videoMDBDAO = videoMDBDAO;
   }
    public void saveVideo(VideoMDB video) {
         videoMDBDAO.saveVideo(video);
    }
     
      public VideoMDB consultar(String nombreArchivo, int recurso) {
         return videoMDBDAO.consultar(nombreArchivo, recurso);
    }
}
