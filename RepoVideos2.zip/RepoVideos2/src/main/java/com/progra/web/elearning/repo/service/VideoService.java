package com.progra.web.elearning.repo.service;

import com.progra.web.elearning.repo.model.Video;
import java.util.List;

/**
 * Interface de Servicio utilizado para hacer consultas al DAO
 * Se utiliza con una base de datos que sea de tipo 
 * SQL
 * @author Dario
 */
public interface VideoService {

    Video findByVideo(String nombreArchivo);
    void saveVideo(Video video);
    void deleteVideo(Video video);
    List<Video> findVideos(String curso);
    List<Video> findVideos();
    Video findVideo(String nombreArchivo);
}
