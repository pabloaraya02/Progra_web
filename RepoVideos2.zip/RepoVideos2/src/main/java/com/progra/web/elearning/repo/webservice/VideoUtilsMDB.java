/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.progra.web.elearning.repo.webservice;

import com.progra.web.elearning.repo.model.Video;
import com.progra.web.elearning.repo.model.VideoMDB;
import com.progra.web.elearning.repo.service.VideoServiceMDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Clase utilizada para realizar los llamados a los servicios de la insercion y
 * consulta de la base de datos en MongoDB
 *
 * @author Dario
 */
@Service
public class VideoUtilsMDB {

    /*Hace una inyeccion de dependencia por atributo
    a la clase del servicio que inserta y consulta los registros de 
    video*/
    @Autowired
    VideoServiceMDB service;

    public void setVideoMDBService(VideoServiceMDB videoService) {
        this.service = videoService;
    }

    public Boolean insertarRegistro(String nombreArchivo, int curso, int week, int recurso) {
        VideoMDB video = new VideoMDB();
        
        // video.setId(1); // sino se indica la identificacion, la autogenera
        video.setCurso(curso);
        video.setWeek(week);
        
        video.setNombreArchivo(nombreArchivo);
        video.setRuta("C:\\repositorio");
        video.setRecurso(recurso);
        service.saveVideo(video);
        return true;
    }

    public VideoMDB consultar(String nombreArchivo, int recurso) {
        return service.consultar(nombreArchivo, recurso);
    }
}
