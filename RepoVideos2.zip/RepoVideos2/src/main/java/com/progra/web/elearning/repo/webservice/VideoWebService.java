/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.progra.web.elearning.repo.webservice;

import com.progra.web.elearning.repo.model.VideoMDB;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.MTOM;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

/**
 * Clase que es mapeada con las operaciones del servicio web
 * Cuenta con dos metodos para poder subir y descargar videos
 * al repositorio
 * @author Dario
 */
@Service
//@StreamingAttachment(parseEagerly = true, memoryThreshold = 40000L)
/*Permite la mejor carga de archivos, establece que el nombre delservicio
que accede el servicio web por Spring. La ruta es 
http://localhost:9999/MtomStreamingService?wsdl*/
@MTOM
@WebService(name = "VideoWebService",
        serviceName = "MtomStreamingService",
        targetNamespace = "http://example.org")
public class VideoWebService extends SpringBeanAutowiringSupport {

    /**
     * This is a sample web service operation
     */
    @Autowired
    VideoUtilsMDB service;

    public void setVideoMDBUtils(VideoUtilsMDB service) {
        this.service = service;
    }

    @WebMethod
    public byte[] descargar(@WebParam(name = "nombreArchivo") String nombre_archivo, int recurso) {
        VideoMDB video = service.consultar(nombre_archivo, recurso);
        //supone que hay un repositorio en el servidor donde almacenar los videos
        String filePath = video.getRuta() + File.separator + video.getNombreArchivo();
        System.out.println("Sending file: " + filePath);

        try {
            //lee el archivo del repositorio
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);
            BufferedInputStream inputStream = new BufferedInputStream(fis);
            byte[] fileBytes = new byte[(int) file.length()];
            inputStream.read(fileBytes);
            inputStream.close();
            //regresa el archivo completo 
            return fileBytes;
        } catch (IOException ex) {
            System.err.println(ex);
            throw new WebServiceException(ex);
        }
    }

    @WebMethod
    public Boolean subir(@WebParam(name = "nombreArchivo") String nombre_archivo, byte[] data, int id_course, int id_week, int id_resource) {
        //supone que hay un repositorio en el servidor donde almacenar los videos
        String filePath = "c:/repositorio" + File.separator + nombre_archivo;   
           System.out.println("DATA:11 " + data);  
        try {
            //recibe el archivo en bytes
            FileOutputStream fos = new FileOutputStream(filePath);
            System.out.println("DATA: " + data);  
            BufferedOutputStream outputStream = new BufferedOutputStream(fos);
            outputStream.write(data);
            outputStream.close();

            System.out.println("Received file: " + filePath);

        } catch (IOException ex) {
            System.err.println(ex);
            throw new WebServiceException(ex);
        }
        //inserta el registro en la base de datos de monto
        return service.insertarRegistro(nombre_archivo,id_course,id_week,id_resource);
        
        //return true;
    }

}
