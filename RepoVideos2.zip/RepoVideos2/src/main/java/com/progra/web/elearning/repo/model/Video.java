package com.progra.web.elearning.repo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Entidad correspondiente al servicio publico Esta entidad es generica para
 * todos los servicios, pero podria extenderse para que otras clases la puedan
 * utilizar
 * Funciona con una base de datos de SQL. La anotaciones tienen esa funcionalidad.
 * @author Dario
 */
@Entity
@Table(name = "VIDEO")
public class Video {

    @Id
    @GeneratedValue
    @Column(name = "ID_VIDEO")
    private int id;

    @Column(name = "CURSO")
    private String curso;

    @Column(name = "RECURSO")
    private int recurso;

    @Column(name = "NOMBRE_ARCHIVO")
    private String nombreArchivo;
    
    @Column(name = "RUTA")
    private String ruta;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the curso
     */
    public String getCurso() {
        return curso;
    }

    /**
     * @param curso the curso to set
     */
    public void setCurso(String curso) {
        this.curso = curso;
    }

    /**
     * @return the recurso
     */
    public int getRecurso() {
        return recurso;
    }

    /**
     * @param recurso the recurso to set
     */
    public void setRecurso(int recurso) {
        this.recurso = recurso;
    }

    /**
     * @return the nombreArchivo
     */
    public String getNombreArchivo() {
        return nombreArchivo;
    }

    /**
     * @param nombreArchivo the nombreArchivo to set
     */
    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    /**
     * @return the ruta
     */
    public String getRuta() {
        return ruta;
    }

    /**
     * @param ruta the ruta to set
     */
    public void setRuta(String ruta) {
        this.ruta = ruta;
    }
}
