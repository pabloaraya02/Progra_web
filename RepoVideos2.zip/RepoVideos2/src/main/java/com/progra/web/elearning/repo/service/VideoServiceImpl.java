package com.progra.web.elearning.repo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import com.progra.web.elearning.repo.dao.VideoDAO;
import com.progra.web.elearning.repo.model.Video;

/**
 * Clase que implementa la funcionalidad para acceder a los DAOs en una
 * conexion por base de datos en SQL
 * La anotacion Service permite incluir en el iOC container de Sprng a 
 * la clase respectiva.
 * La etiqueta transaccional permite que la clase pueda ser transaccional al hacer operaciones por BD
 * @author Dario
 */
@Service("VideoService")
@Transactional(readOnly = true )
public class VideoServiceImpl implements VideoService {

    /*Hace una inyeccion por dependencia en el atributo para instanciar
    la clase VideoDAO y poder hacer uso de sus metodos*/
    @Autowired
    private VideoDAO videoDAO;

    public void setVideoDAO(VideoDAO videoDAO) {
		this.videoDAO = videoDAO;
	}

	@Override
    public Video findByVideo(String dueno) {
        return videoDAO.findById(dueno);
    }

    @Override
    @Transactional(readOnly = false)
    public void saveVideo(Video video) {
        videoDAO.saveVideo(video);
    }

    @Override
    @Transactional(readOnly = false)
    public void deleteVideo(Video video) {
        if (video != null) {
        	videoDAO.delete(video);
        }
    }

    @Override
    public List<Video> findVideos(String curso) {
        return videoDAO.findVideos(curso);
    }
    
    @Override
    public List<Video> findVideos() {
        return videoDAO.findAllVideos();
    }
    
    @Override
    public Video findVideo(String nombreArchivo) {
        Video servicio = videoDAO.findVideo(nombreArchivo);
        Video nuevo = new Video();
        nuevo.setNombreArchivo(servicio.getNombreArchivo());
        nuevo.setRecurso(servicio.getRecurso());
        nuevo.setCurso(servicio.getCurso());
        nuevo.setId(servicio.getId());
        return nuevo;
    }
}
