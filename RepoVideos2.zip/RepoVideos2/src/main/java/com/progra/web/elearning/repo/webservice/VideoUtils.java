/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.progra.web.elearning.repo.webservice;

import com.progra.web.elearning.repo.model.Video;
import com.progra.web.elearning.repo.service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Utilidad de clase para poder guardar los datos haciendo de los servicios para
 * una base de datos en SQL
 *
 * @author Dario
 */
@Service
public class VideoUtils {

    /*Inyeccion de dependencia para la clase videoService
    que se le hace al atributo para hacer uso de sus metodos*/
    @Autowired
    VideoService service;

    public void setVideoService(VideoService videoService) {
        this.service = videoService;
    }

    public Video getConsulta(String nombreArchivo) {
        return service.findVideo(nombreArchivo);
    }

    public Boolean insertarRegistro(String nombreArchivo) {
        //service.saveVideo();
        return true;
    }
}
