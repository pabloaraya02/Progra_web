package com.progra.web.elearning.repo.dao;

import org.hibernate.criterion.Criterion;

import java.io.Serializable;
import java.util.List;

/**
 * Interface para el manejo de datos e insercion 
 * en una base de datos SQL
 * @author Dario
 * @param <E>
 * @param <I> 
 */
public interface AbstractDAO<E, I extends Serializable> {

    E findById(I id);
    void saveOrUpdate(E e);
    List<E> findByCriteria(Criterion criterion);
    List<E> getAll(String query);
    boolean delete(E e);
    E findByFilter(List<Criterion> criterion);
     E saveOrUpdateWithReturn(E e);
     
}
